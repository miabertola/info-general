#archivos -> este archivo tiene que estar en el mismo directorio porque si
#no no lo encuentra
def arch01():
    arch=open("datos.txt","r")
    lsArch=arch.readlines()#lectura secuencial, solo lo puedo ver una sola vez
    #print(lsArch)
    for linea in lsArch:
        print(linea[:-1])
        #print(linea,end="")
        
        
    arch.close() #SIEMPRE HAY QUE CERRARLOS

def arch02():
    arch=open("datos.text","r")
    linea=arch.readline()
    while linea!="":
        print(linea[:-1])
        linea=arch.readline()
    arch.close()
    
def arch03():
    arch=open("nuevo.txt","w")#si hacemos un open de un archivo que ya existe, lo borras
    arch.write("contenido blblbl")
    arch.write("\nCHAUUU")
    arch.close()
    
def arch04(nomArch):
    arch=open(nomArch,"a")
    arch.write("agregando\n")
    arch.close()
    
#csv separa los valores con coma

def arch05(nomArch):
    lsRes=[]
    arch=open(nomArch,"r")
    lsArch=arch.readlines()
    for linea in lsArch:
        lsLinea=linea[:-1].split(",")
        lsLinea[0]=float(lsLinea[0])
        lsLinea[2]=int(lsLinea[2])
        lsRes.append(lsLinea)
        #print(linea[:-1])
        lsRes.append(lsLinea)
    
    arch.close()
    return lsRes
    
def main():
#     arch01()
#     arch02()
#     arch03()
#     arch04("nuevo.txt")
    ls=arch05("datos2.txt")
    print(ls) #reemplazar el print por otra funcion que lo cambia por una tabla
    
main()