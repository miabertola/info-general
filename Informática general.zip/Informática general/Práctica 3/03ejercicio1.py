def operaciones(n1,n2,caracter):
    
    if caracter=="+":
        res=n1+n2
    
    elif caracter=="-":
        res=n1-n2
    
    elif caracter=="*":
        res=n1*n2
        
    elif caracter=="/":
        res=n1/n2
        
    return res

def main():
    num1=int(input("Ingrese el primer numero: "))
    num2=int(input("Ingrese el segundo número: "))
    caracter=(input("Ingrese la operacion (+,-,*,/) :"))
    if caracter=="+"or caracter=="-"or caracter=="*"or (caracter=="/" and num2!=0):
        resultado=operaciones(num1,num2,caracter)
        print("{:d} {} {:d}={:.2f}".format(num1,caracter,num2,resultado))
    else:
        print("Operacion invalida")
    
main()