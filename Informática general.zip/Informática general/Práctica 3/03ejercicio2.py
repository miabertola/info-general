def numeros(num1,num2,num3):
    if num1>=num2 and num2>=num3:
        res="Los numeros ordenados en forma ascendente son:\n{}\n{}\n{}".format(num3,num2,num1)
    
    elif num2>=num1 and num1>=num3:
        res="Los numeros ordenados en forma ascendente son:\n{}\n{}\n{}".format(num3,num1,num2)
    
    elif num1>=num3 and num3>=num2:
        res="Los numeros ordenados en forma ascendente son:\n{}\n{}\n{}".format(num2,num3,num1)
    
    elif num2>=num3 and num3>=num1:
        res="Los numeros ordenados en forma ascendente son:\n{}\n{}\n{}".format(num1,num3,num2)
        
    elif num3>=num1 and num1>=num2:
        res="Los numeros ordenados en forma ascendente son:\n{}\n{}\n{}".format(num2,num1,num3)
        
    elif num3>=num2 and num2>=num1:
        res="Los numeros ordenados en forma ascendente son:\n{}\n{}\n{}".format(num1,num2,num3)
    
    return res

def main():
    num1=int(input("Ingrese el primer numero: "))
    num2=int(input("Ingrese el segundo numero: "))
    num3=int(input("Ingrese el tercer numero: "))
    print(numeros(num1,num2,num3))
    
main()