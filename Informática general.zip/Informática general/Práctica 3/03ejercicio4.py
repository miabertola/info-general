def booleana(a,b):
    if a>b:
        mayor=a
        menor=b
        
    else:
        b>a
        mayor=b
        menor=a
        
    if (mayor-menor)>=menor and mayor>=(mayor-menor):
        
        res="SI cumple condicion"

    else:
        res="NO cumple condicion."
        
    return res

def main():
    a=int(input("Ingrese un numero A: "))
    b=int(input("Ingrese un numero B: "))
    print(booleana(a,b))
    
main()