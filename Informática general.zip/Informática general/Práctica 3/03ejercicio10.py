def multa(a,b,c):
    velmin=b/2
    tolmax=b*1.15
    tolmin=b*0.85
    if c=="s" and a>=velmin:
        return "No recibe multa."
    elif a<=b and a>velmin:
        return "No recibe multa."
    elif a>b and a<tolmax and c=="n":
        return "Advertencia."
    elif a<velmin and a>tolmin:
        return "Advertencia."
    elif a>tolmax:
        return "Recibe multa por exceso de velocidad."
    elif a<tolmin:
        return "Recibe multa por entorpecer el tránsito."

def main():
    vel=int(input("Velocidad del vehículo: "))
    velmax=int(input("Velocidad máxima: "))
    em=input("Emergencia (s/n): ")
    print(multa(vel,velmax,em))

main()