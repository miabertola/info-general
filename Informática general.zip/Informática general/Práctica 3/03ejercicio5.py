def booleana(d,m,a):
    if d<=0 or m<=0 or a<=0:
        return 0
    elif m==2 and d<=29 and (a%400)==0 or ((a%4)==0 and a%100!=0):
        return 1    
    elif m==2 and d<=28:
        return 1
    elif m!=2 and m!=4 and m!=6 and m!=9 and m!=11 and d<=31:
        return 1
    elif m!=2 and (m==4 or m==6 or m==9 or m==11) and d<=30:
        return 1    
    else:
        return 0
    
def main():
    d=int(input("Ingrese el dia: "))
    m=int(input("Ingrese el mes: "))
    a=int(input("Ingrese el año: "))
    codigo=booleana(d,m,a)
    verdadero=codigo*"correcta"
    falso=(1-codigo)*"incorrecta"
    final=verdadero+falso
    print("- {}/{}/{} es {}".format(d,m,a,final))

main()
    