def trimedio(n1,n2,n3):
        promedio=(n1+n2+n3)/3
        return promedio

def cuatrimedio(n1,n2,n3,rec):
            promedio=(n1+n2+n3+rec)/4
            return promedio
 
def main():
    n1=int(input("Ingrese la nota del primer parcial: "))
    n2=int(input("Ingrese la nota del segundo parcial: "))
    n3=int(input("Ingrese la nota del tercer parcial: "))
    if n1>=4 and n2>=4 and n3>=4 and (trimedio(n1,n2,n3))>=7:
        print("Promedio general= {:.2f}\nEl alumno promociona la materia.".format(trimedio(n1,n2,n3)))
    elif n1>=4 and n2>=4 and n3>=4 and (trimedio(n1,n2,n3))<7:
        print("Promedio general= {:.2f}\nEl alumno deberá rendir final.".format(trimedio(n1,n2,n3)))
    elif n1<4 or n2<4 or n3<4:
        rec=int(input("Ingrese la nota del recuperatorio: "))
        if rec>=4:
            print("Promedio general= {:.2f}\nEl alumno deberá rendir final.".format(cuatrimedio(n1,n2,n3,rec)))
        elif rec<4:
            print("Promedio general= {:.2f}\nEl alumno fue aplazado.".format(cuatrimedio(n1,n2,n3,rec)))
        
    
main()