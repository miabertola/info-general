def mensaje(c1,c5,met):
    cn5=met//5
    cn1=met%5
    if cn5<=c5:
        if cn1<=c1:
            return "Se puede cubrir el tendido.\nSugerencia:\n{} unidades de caño de 5 metros\n{} unidades de caño de 1 metro".format(cn5,cn1)
    
        else:
            return "No es posible cubrir el tendido."

    else:
        falta=cn5-c5
        cn1=falta*5+cn1
        if cn1<=c1:
            return "Se puede cumplir el tendido.\nSugerencia:\n{} unidades de caño de 5 metros\n{} unidades de caño de 1 metro".format(c5,cn1)
    
        else:
            return "No es posible cubrir el tendido."
    
def main():
    c1=int(input("Cantidad de caños de 1 metro: "))
    c5=int(input("Cantidad de caños de 5 metros: "))
    met=int(input("Metros totales a cubrir: "))
    print(mensaje(c1,c5,met))
    
main()
    