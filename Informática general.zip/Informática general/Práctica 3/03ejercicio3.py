def signo(num):
    if num>0:
        res="positivo"
    
    elif num<0:
        res="negativo"
        
    elif num==0:
        res="cero"
        
    return res

def tipoDeDato(num):
    if num>0 and num-(num//1)==0:
        tipo="entero natural"
        
    elif num-(num//1)==0:
        tipo="entero"
    
    else:
        tipo="real"
    
    return tipo

def main():
    num=float(input("Ingrese un numero: "))
    print("El numero es {} y {}.".format(signo(num),tipoDeDato(num)))
    
main()