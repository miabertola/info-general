def booleana(num):
    if num%2==0:
        menor=int(input("Ingrese un numero menor que {}: ".format(num)))
        if menor<num:
            return 1
            
        elif menor>num:
                return 0
    
    elif num>0 and num%2==1:
        mayor=int(input("Ingrese un numero mayor que {}: ".format(num)))
        if mayor>num:
            return 1     
        elif mayor<num:
            return 0
    else:
        return 0

def main():
    num=int(input("Ingrese un numero entero positivo: "))
    codigo=(booleana(num))
    frase=codigo*"Correcto!"+(1-codigo)*"Incorrecto!"
    print(frase)
    
main()
        