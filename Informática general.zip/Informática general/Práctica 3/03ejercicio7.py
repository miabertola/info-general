def booleana(num1,num2,num3):
    if num1>=num2 and num2>=num3 and (num1-num2)==(num2-num3):
        res="Están igualmente distanciados!"
    
    elif num2>=num1 and num1>=num3 and (num2-num1)==(num1-num3):
        res="Están igualmente distanciados!"
    
    elif num1>=num3 and num3>=num2 and (num1-num3)==(num3-num2):
        res="Están igualmente distanciados!"
    
    elif num2>=num3 and num3>=num1 and (num2-num3)==(num3-num1):
        res="Están igualmente distanciados!"
        
    elif num3>=num1 and num1>=num2 and (num3-num1)==(num1-num2):
        res="Están igualmente distanciados!"
        
    elif num3>=num2 and num2>=num1 and (num3-num2)==(num2-num1):
        res="Están igualmente distanciados!"
    
    else:
        res="NO Están igualmente distanciados!"
    
    return res

def main():
    num1=int(input("Ingrese el primer numero: "))
    num2=int(input("Ingrese el segundo numero: "))
    num3=int(input("Ingrese el tercer numero: "))
    print(booleana(num1,num2,num3))
    
main()
