def bono(sbase):
    if sbase>=2000:
        bonus=sbase*0.15
        return bonus
    else:
        bonus=sbase*0.2
        return bonus

def plusH(sbase,hijos):
    if hijos=="s":
        plusHijos=sbase*0.05
        return plusHijos
    else:
        return 0

def plusC(sbase,cat):
    if cat==1 or cat==2 or cat==3:
        plusCat=sbase*0.10
        return plusCat
    elif cat==4 or cat==5 or cat==6:
        plusCat=sbase*0.12
        return plusCat
    elif cat==7 or cat==8 or cat==9:
        plusCat=sbase*0.20
        return plusCat
    else:
        return 0

def plus(sbase,hijos,cat):
    plusHC=plusH(sbase,hijos)+plusC(sbase,cat)
    return plusHC

def main():
    sbase=int(input("Ingrese el sueldo base: "))
    hijos=input("Tiene hijos (s/n)?: ")
    cat=int(input("Ingrese categoría (1 - 9): "))
    sueldoTotal=sbase+bono(sbase)+plus(sbase,hijos,cat)
    print("El sueldo total será de ${:.2f}".format(sueldoTotal))

main()