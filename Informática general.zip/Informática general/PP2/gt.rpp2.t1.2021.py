def esLetra(l):
    res=False
    acentos=l in ("áéíóúüÁÉÍÓÚÜ")
    if l>="a" and l<="z" or l>="A" and l<="Z":
        res= True
    return res

def esVocal(c):
    if c in ("aeiouüáéíóúAEIOUÁÉÍÓÚÜ"):
        return True
    else:
        return False

def listita(texto):
    ls=[]
    i=0
    while i<len(texto):
        while i<len(texto) and not esLetra(texto[i]):
            i+=1
        pal=""
        cont=0
        while i<len(texto) and esLetra(texto[i]):
            if (esVocal(texto[i])):
                cont+=1
            pal+=texto[i]
            i+=1
        if cont>=3:
            ls.append(pal)
    return ls
    
def main():
    print(listita("...,Otto Orozco y Hans Orozco--, quisieran rodar sus maquinas! Vamos hombres!!!!!!"))
    
main()