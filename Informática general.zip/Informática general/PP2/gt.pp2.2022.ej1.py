# def esLetra(c):
#     res=False
#     acentos=c in "áéíóúÜÁÉÍÓÚüñÑ"
#     if c>="a" and c<="z" or c>="A" and c<="Z":
#         res=True
#     return res

def es_monovocalica(pal):
    res=0
    for i in range(len(pal)):
        if pal[i]=="a":
            resa=1
            return resa
        if pal[i]=="e":
            rese=1
            return rese
        if pal[i]=="i":
            resi=1
            return resi
        if pal[i]=="o":
            reso=1
            return reso
        if pal[i]=="u":
            resu=1
            return resu
    return (resa+rese+resi+reso+resu)

# def crear_lista(texto):
#     ls=[]
#     i=0
#     while i<len(texto):
#         while i<len(texto) and not esLetra(texto[i]):
#             i+=1
#         pal=""
#         while i<len(texto) and esLetra(texto[i]):
#             pal+=texto[i]
#             i+=1
#         if es_monovocalica(pal)==1 and pal not in ls:
#             ls.append(pal)
#     return ls
# 
# def main():
#     texto="_a veces sentimos que lo que hacemos es tan solo una gota en el mar!!!!,pero el mar seria mucho menos si le faltara una gota_"
#     print(crear_lista(texto))
#     
# main()