def esLetra(c):
    if c>="a" and c<="z" or c>="A" and c<="Z":
        return True
    else:
        return False

def invertir(pal):
    vocales="aeiouAEIOU"
    cont=0
    for i in pal:
        if i in vocales:
            cont+=1
    if cont%2==0:
        return pal[::-1]
    else:
        return pal
    
def obtenerNuevoTexto(texto):
    i=0
    while i<len(texto):
        while i<len(texto) and not esLetra(texto[i]):
            i+=1
        pal=""
        while i<len(texto) and esLetra(texto[i]):
            pal+=texto[i]
            pal=invertir(pal)
            
    return pal

def main():
    texto="hola como estas paz"
    print(obtenerNuevoTexto(texto))
    
main()