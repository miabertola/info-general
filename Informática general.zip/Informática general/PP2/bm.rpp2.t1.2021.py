def esLetra(c):
    res=False
    acentos= c in ("áéíóúüÁÉÍÓÚÜ")
    if c>="a" and c<="z" or c>="A" and c<="Z":
        res=True
    return res

def condicion(pal):
    i=0
    v=0
    c=0
    while i<len(pal):
        if pal[i] in ("aeiouAEIOUáéíóúüÁÉÍÓÚÜ"):
            v+=1
            i+=1
        elif pal[i] in ("bcdfghjklmnñpqrstvwxyzBCDFGHJKLMNÑPQRSTVWXYZ"):
            c+=1
            i+=1
    if v>c and (len(pal)%2)!=0:
        return True
    else:
        return False

def buscarPalabras(texto):
    i=0
    pal=""
    res=""
    while i<len(texto):
        while i<len(texto) and not esLetra(texto[i]):
            i+=1
        pal=""
        while i<len(texto) and esLetra(texto[i]):
            pal+=texto[i]
            i+=1
        if condicion(pal)==True:
            if res!="":
                res=res+" "+pal
            else:
                res=pal
    return res

def main():
    print(buscarPalabras("xyzXYZ,_xyXYZ_#ABC abccba aaa aAa"))
    print(buscarPalabras("Si uno No zyzYZ sabe A que puerto NAVega."))
    print(buscarPalabras("++Meme@ LAaLA NOMbran las @estrellas_*_"))
    print(buscarPalabras("#hoLAaas_xxx_1212"))
    print(buscarPalabras("#ABaba#_*XYxy* 12121_"))
    print(buscarPalabras("A-AB-ZZ-ZZZ"))
    
main()