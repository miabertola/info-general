def esLetra(c):
    res=False
    acentos=c in "áéíóúñüÁÉÍÓÚÑÜ"
    if c>="a" and c<="z" or c>="A" and c<="Z":
        res=True
    return res

def condicion(pal,nVoc):
    vocales="aeiouáéíóúüÁÉÍÓÚÜAEIOU"
    cont=0
    for i in pal:
        if i in vocales:
            cont+=1
    return nVoc==cont

def extraePal(texto,nVoc):
    ls=[]
    i=0
    while i<len(texto):
        while i<len(texto) and not esLetra(texto[i]):
            i+=1
        pal=""
        while i<len(texto) and esLetra(texto[i]):
            pal+=texto[i]
            i+=1
        if pal!="":
            if condicion(pal,nVoc):
                ls.append(pal)
    return ls

def main():
    texto="_A veCes Mmmhh!!!sentimos que soLo_faltariA Una gota En el mar!!!!,"
    print(extraePal(texto,0))
    print(extraePal(texto,1))
    print(extraePal(texto,2))
    print(extraePal(texto,3))
    print(extraePal(texto,4))
    print(extraePal(texto,5))
    print(extraePal(texto,70))
    
main()