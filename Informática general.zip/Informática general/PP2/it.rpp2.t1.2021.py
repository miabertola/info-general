def esLetra(c):
    if c in "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZÁÉÍÓÚüáéíóúÜ":
        res=True
    else:
        res=False
    return res

# def esLetra(c):
#     res=False
#     acentos=c in ("áéíóúüÁÉÍÓÚÜñÑ")
#     if c>="a" and c<="z" or c>="A" and c<="Z":
#         res=True
#     return res

def bilidad(texto):
    ls=[]
    i=0
    while i<len(texto):
        while i<len(texto) and not esLetra(texto[i]):
            i+=1
        pal=""
        while i<len(texto) and esLetra(texto[i]):
            pal=texto[i]
            i+=1
        if "bilidad" in pal and pal not in ls:
            ls.append(pal)
    return ls

def main():
    texto="gracias por su amabilidad, su Santidad tiene la habilidad de transmitir estabilidad con amabilidad."
    res=bilidad(texto)
    print(res)

main()