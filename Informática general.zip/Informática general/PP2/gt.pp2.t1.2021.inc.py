def cargarLista(ls):
    x=int(input("Ingrese un numero o 0 (cero) para terminar: "))
    while x<0:
        x=int(input("ERROR. NUMERO NEGATIVO.Ingrese un numero: "))
    while x!=0:
        ls.append(x)
        x=int(input())
        while x<0:
            x=int(input("ERROR. NUMERO NEGATIVO.Ingrese un numero: "))
def mostrar(ls,n):
    menores=[]
    
    
def main():
    ls=[]
    n=int(input("Ingrese numero mayor a 0: "))
    
main()