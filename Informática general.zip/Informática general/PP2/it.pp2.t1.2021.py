def promedio(ls):
    suma=0
    contador=0
    for i in ls:
        suma+=i
        contador+=1
    return suma/contador

def eliminar(ls,prom):
    i=0
    while i<len(ls):
        if ls[i]>prom:
            ls.remove(ls[i])
        else:
            i+=1
            
def main():
    ls=[24,30,2,10,15,6,65,42]
    prom=promedio(ls)
    print("promedio: {}".format(prom))
    print("lista original", ls)
    eliminar(ls,prom)
    print("lista modificada:",ls)
    
main()
    