def esLetra(c):
    res=False
    acentos=c in "áéíóúÜÁÉÍÓÚüñÑ"
    if c>="a" and c<="z" or c>="A" and c<="Z":
        res=True
    return res

def mostrar(texto):
    ls=[]
    i=0
    while i<len(texto):
        while i<len(texto) and not esLetra(texto[i]):
            i+=1
        pal=""
        while i<len(texto) and esLetra(texto[i]):
            pal+=texto[i]
            i+=1
        if pal not in ls:
            ls.append(pal)
    return ls

def main():
    texto=input("Ingrese texto: ")
    print("Lista de palabras sin repetidos: ",mostrar(texto))

main()