def masRepetido(ls):
    lsMax=[]
    if len(ls)>0:
        lsMax=(ls[0],1)
    for i in range(0,len(ls)):
        cont=0
        for x in range(0,len(ls)):
            if ls[i]==ls[x]:
                cont+=1
        if lsMax[1]<cont:
            lsMax=[ls[i],cont]
    return lsMax

def main():
    print(masRepetido([5,2,71,9,4,44,63,42,99,17,16,3,6,1]))
    print(masRepetido([6,6,6,2,2,4,2]))
    print(masRepetido([1,3,7,2,7,4,9]))
    print(masRepetido([1,9,3,9,2,4,9,9]))
    print(masRepetido([86]))
    print(masRepetido([]))

main()