def esLetra(c):
    res=False
    acentos= c in ("áéíóúÁÉÍÓÚñÑÜü")
    if c>="a" and c<="z" or c>="A" and c<="Z":
        res= True
    return res

def esVocal(c):
    return c in ("aeiouAEIOUáéíóúüÁÉÍÓÚÜ")

def esConsonante(c):
    return c in ("bcdfghjklmnpqrstvwxyz")

def condicion(pal):
    cvc=0
    cva=0
    for i in pal:
        if i in ("aeoAEO"):
            cva+=1
            
        if i in ("iuIU"):
            cvc+=1
    if cva==cvc:
        return True
    else:
        return False

def maxima(sec):
    palMax=""
    i=0
    while i<len(sec):
        while i<len(sec) and not esLetra(sec[i]):
            i+=1
        pal=""
        while i<len(sec) and esLetra(sec[i]):
            pal+=sec[i]
            i+=1
        
        if pal!="":
            if condicion(pal)==True:
                if len(palMax)<len(pal):
                    palMax=pal
    return palMax

def main():
    print(maxima(""))
    print(maxima("abc"))
    print(maxima("aie"))
    print(maxima("t^pucho $ pichichu &"))
    print(maxima("pucho,-,pucherito-nito^carlin"))
    print(maxima("? roki +roi nahuelhuapi-huechulafquen $"))
    print(maxima("$guam - chau &"))
    
main()
        