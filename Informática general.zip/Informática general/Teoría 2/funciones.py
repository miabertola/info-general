def sumar(numero1,numero2):
    suma=numero1+numero2
    return suma
    
def main():
    n1=int(input("Ingrese numero"))
    n2=int(input("Ingrese numero"))
    resultado=sumar(n1,n2)
    print("el resultado final es: ",resultado)
    
main()