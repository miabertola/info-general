def imprimirnombre(n,a):
    #todo lo que haga la funcion va a estar escrito a un tab de distancia
    print("n")
    print("a")

def main():
    nombre=input("Ingrese nombre")
    apellido=input("Ingrese apellido")
    imprimirnombre(nombre,apellido)
    print("siguiente linea")
    
main()