def saludo(nom,ape):
    print("hola") #estas son definiciones
    print(nom,ape)
    print("------")
    
def despedida(nom):
    res="chau"+"\n"+nom
    return res
    
def main():
    nom="Luis"
    saludo(nom,"Perez")
    resultado=despedida("lola")
    print(resultado)
    resultado=despedida("lolita")
    print(resultado)
    
main()