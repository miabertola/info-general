#condiciones logicas
def esPosYPar(num):
    #retorna True si num es positivo y ademas es un numero par
    resultado=num>0 and num%2==0
    return resultado

def main():
    print(esPosYPar(26))
    
main()