def tipoNum(num):
    if num>=0:
        #verdadero
        if num==0:
            res="El numero es 0"
        else:
            res="El numero es positivo"
    else:
        #falso
        res="El numero es negativo"
        
    return res

def main():
    numero=12 #input
    print(tipoNum(numero))
    
main()