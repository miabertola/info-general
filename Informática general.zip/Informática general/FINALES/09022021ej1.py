def aprobadas(lstAlumnos,lstMaterias,lstCursadas,nombre):
    lsfin=[]
    lsalumnos=[]
    for line in lstAlumnos:
        lsline=line[:-1].split(",")
        lsline[0]=int(lsline[0])
        lsalumnos.append(lsline)
        if nombre==lsline[1]:
            aluid=lsline[0]
    lsmat=[]
    for lineas in lstMaterias:
        lslineas=lineas[:-1].split(",")
        lslineas[0]=int(lslineas[0])
        lsmat.append(lslineas)
    lscursadas=[]
    for linea in lstCursadas:
        lslinea=linea[:-1].split(",")
        lslinea[0]=int(lslinea[0])
        lslinea[1]=int(lslinea[1])
        lslinea[2]=float(lslinea[2])
        lscursadas.append(lslinea)
    for lineac in lscursadas:
        if aluid in lineac[1] and lineac[2]>=4:
            idmat=lineac[0]
            nota=lineac[2]
            for lineas in lsmat:
                if idmat==lineas[0]:
                    mat=lineas[1]
            tup=(mat,nota)
            lsfin.append(tup)
    return lsfin
            
def main():
    print("Prueba para el EJ01")
    lstAlumnos = ['152002,Juan Gonzalez\n','152001,Ana Martinez\n','151988,Ricardo Bochini\n','180372,Vicente Pernia\n']
    lstMaterias = ['132,Informática Gral\n', '127,Álgebra y Geometría\n', '137,Física I\n']
    lstCursadas = ['137,152001,4.0\n', '127,151988,6.0\n', '137,151988,7.5\n' ,'132,152002,2.0\n','132,151988,6.0\n', '127,152001,2.0\n', '127,180372,10.0\n']
    print(aprobadas(lstAlumnos,lstMaterias,lstCursadas,'Ricardo Bochini'))
    
main()