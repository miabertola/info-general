def lsdelsE(lstEnergia):
    lsE=[]
    for line in lstEnergia:
        lsLinea=line[:-1].split(",")
        lsLinea[1]=int(lsLinea[1])
        lsLinea[2]=float(lsLinea[2])
        lsE.append(lsLinea)
    return lsE

def lsdelsP(lstParque):
    lsP=[]
    for line in lstParque:
        lsLinea=line[:-1].split(",")
        lsLinea[0]=int(lsLinea[0])
        lsLinea[2]=int(lsLinea[2])
        lsP.append(lsLinea)
    
    return lsP

def energiaTotal(n,lstEnergia,lstParque):
    ls=[]
    for lsdels in lstParque:
        lineaP=lsdels
        suma=0
    suma+=
        molino=lsdels[2]
        clave=[nombre,suma,suma/molino]
    return n*clave
    


def main():
    lstEnergia = ['101205, 1, 24.2\n', '110607, 8, 54.4\n', '120318, 3, 18.1\n', '090501, 9, 88.4\n', '101209, 1, 26.8\n', '101217, 3, 22.4\n', '190101, 8, 44.0\n']
    lstParque = ['1,Rosario, 8\n', '6,San Martin, 4\n', '8,Lavalle, 10\n', '3,Esperanza, 3\n', '7,General Pico, 9\n', '9,P.Madryn, 4\n']
    n=3
    print(energiaTotal(n,lstEnergia,lstParque))
    
main()