def minimos(lstEnergia):
    lsE=[]
    ls=[]
    for lineE in lstEnergia:
        lslineE=lineE[:-1].split(",")
        lslineE[2]=float(lslineE[2])
        lsE.append(lslineE)
    minimo=lsE[0][2]
    for line in lsE:
        if minimo>line[2]:
            minimo=line[2]
            año=line[0][:2]
    uno=(año,minimo)
    ls.append(uno)
    for line in lsE:
        if minimo in line:
            am=line[0][:4]
    dos=(am,minimo)
    ls.append(dos)
    return ls
    
def main():
    print("Prueba para el EJ01")
    lstEnergia = ['101205,1,24.2\n', '110607,8,54.4\n', '120318,3,18.1\n','090501,9,88.4\n', '101209,1,26.8\n', '101217,3,22.4\n', '190101,8,44.0\n']
    print(minimos(lstEnergia))
    
main()