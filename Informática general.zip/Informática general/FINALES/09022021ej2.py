def segmentos(lstAlumnos,lstMaterias,lstCursadas):
    di={"M":[],"R":[],"B":[],"E":[]}
    lstC=[]
    for lineC in lstCursadas:
        lslineC=lineC[:-1].split(",")
        lslineC[0]=int(lslineC[0])
        lslineC[1]=int(lslineC[1])
        lslineC[2]=float(lslineC[2])
        lstC.append(lslineC)
        nota=lslineC[2]
        aluid=lslineC[1]
        matid=lslineC[0]
        lstA=[]
        for lineA in lstAlumnos:
            lslineA=lineA[:-1].split(",")
            lslineA[0]=int(lslineA[0])
            lstA.append(lslineA)
            if aluid==lslineA[0]:
                nom=lslineA[1]
        lstM=[]
        for lineM in lstMaterias:
            lslineM=lineM[:-1].split(",")
            lslineM[0]=int(lslineM[0])
            if matid==lslineM[0]:
                mat=lslineM[1]
        if nota<4:
            di["M"]=[[mat,nom]]
        elif nota>=4 and nota<7:
            di["R"]=[[mat,nom]]
        elif nota>=7 and nota<8:
            di["B"]=[[mat,nom]]
        elif nota>=8 and nota<=10:
            di["E"]=[[mat,nom]]
    
    return di
    
def main():
    lstAlumnos = ['152002,Juan Gonzalez\n','152001,Ana Martinez\n','151988,Ricardo Bochini\n','180372,Vicente Pernia\n']
    lstMaterias = ['132,Informática Gral\n', '127,Álgebra y Geometría\n', '137,Física I\n']
    lstCursadas = ['137,152001,4.0\n', '127,151988,6.0\n', '137,151988,7.5\n' ,'132,152002,2.0\n','132,151988,6.0\n', '127,152001,2.0\n', '127,180372,10.0\n']
    print( segmentos(lstAlumnos ,lstMaterias ,lstCursadas ) )
    
main()