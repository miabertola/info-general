def fun1t1(anInf,anSup):
    lsArch = ['(JUV),Cristiano Ronaldo,29,2634,25,162,2016\n','(PSG),Neymar,30,2694,13,105,2016\n', '(BAR),Lionel Messi,32,2910,37,179,2016\n', '(RMA),EdenHazard,36,3101,16,77,2016\n', '(TOT),Dele Alli,35,3182,18,95,2016\n', '(BAR),Lionel Messi,32,3123,33,197,2017\n','(JUV),Cristiano Ronaldo,27,2375,26,178,2017\n', '(BAR),Lionel Messi,29,2849,36,170,2018\n', '(JUV),CristianoRonaldo,30,2857,21,177,2018\n', '(PSG),Angel Di Maria,28,2418,12,97,2018\n', '(PSG),Neymar,16,1517,15,54,2018\n','(MNU),Edinson Cavani,20,1747,18,52,2018\n', '(RMA),Eden Hazard,32,3115,16,93,2018\n', '(BAR),LionelMessi,32,3067,25,159,2019\n', '(JUV),Cristiano Ronaldo,33,3127,31,208,2019\n', '(INT),LautaroMartinez,29,2581,14,125,2019\n', '(PSG),Neymar,15,1396,12,71,2019\n', '(PSG),Angel Di Maria,23,2106,8,74,2019\n','(BAR),Lionel Messi,8,824,4,39,2020\n', '(JUV),Cristiano Ronaldo,5,397,8,26,2020\n']
    di={}
    z=1
    for lineJ in lsArch:
        lslineJ=lineJ[:-1].split(",")
        lslineJ[5]=int(lslineJ[5])
        lslineJ[6]=int(lslineJ[6])
        if lslineJ[6]>=anInf and lslineJ[6]<=anSup:
            if z:
                mayor=lslineJ[5]
                di["año"]=lslineJ[6]
                di["club"]=lslineJ[0]
                di["tiros"]=lslineJ[5]
                z=0
            else:
                if mayor<lslineJ[5]:
                    mayor=lslineJ[5]
                    di["año"]=lslineJ[6]
                    di["club"]=lslineJ[0]
                    di["tiros"]=lslineJ[5]
    return di     
    
def main():
    print(fun1t1(2016,2020))
    print(fun1t1(2016,2016))
    print(fun1t1(2020,2020))
    print(fun1t1(2025,2029))
main()