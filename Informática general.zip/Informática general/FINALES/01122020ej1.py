def ordenar(ls):
    for i in range(len(ls)-1):
        for j in range(1,len(ls)):
            if ls[i][1]<ls[j][1]:
                aux=ls[i]
                ls[i]=ls[j]
                ls[j]=aux

def media_01(n,lstCiudad,lstResiduos):
    suma=0
    cont=0
    cantRT=0
    cantRC=0
    lista=[]
    lsR=[]
    for lineC in lstCiudad:
        lslineC=lineC[:-1].split(",")
        lslineC[0]=int(lslineC[0])
        idciu=lslineC[0]
        nom=lslineC[1]
        for lineR in lstResiduos:
            lslineR=lineR[:-1].split(",")
            lslineR[0]=int(lslineR[0])
            lslineR[1]=int(lslineR[1])
            lslineR[2]=int(lslineR[2])
            lsR.append(lslineR)
            idC=lslineR[1]
            if idciu==idC:
                cantRC+=lslineR[0]
                cont+=1
        if cont!=0:
            lista.append([nom,round((cantRC/cont),1)])
    ordenar(lista)
    for line in lsR:
        cantRT+=line[0]
        suma+=1
    tot=round((cantRT/suma),2)
    tup=(tot,lista[:n])
    return tup 

def main():
    lstCiudad = ['223,Parana\n', '114,Merlo\n', '218,Guaymallen\n', '132,C. Rivadavia\n', '341,Adolfo Alsina\n','404,Jose C. Paz\n']
    lstResiduos = ['33,114,200518\n', '31,223,200519\n', '27,218,200319\n', '26,132,200616\n', '74,341,200319\n','62,404,200606\n', '46,218,200709\n', '55,132,200630\n', '55,341,200612\n', '54,404,200701\n','23,114,200315\n', '55,223,200519\n', '34,218,200319\n', '33,132,200425\n', '27,341,200422\n','21,404,200501\n', '31,114,200503\n', '44,114,200513\n', '44,218,200519\n']
    print(media_01(7,lstCiudad,lstResiduos))
    
main()