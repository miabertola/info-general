def media_02(lstResiduos):
    di={}
    for mes in range(3,13):
        suma=0
        cont=0
        for lineR in lstResiduos:
            lslineR=lineR[:-1].split(",")
            m=int(lslineR[2][2:4])
            res=int(lslineR[0])
            if mes==m:
                suma+=res
                cont+=1
        if cont!=0:
            prom=round((suma/cont),1)
            di[mes]=prom
    return di
            
def main():
    print("Prueba para el EJ02")
    lstResiduos = ['33,114,200518\n', '31,223,200519\n', '27,218,200319\n', '26,132,200616\n','74,341,200319\n', '62,404,200606\n', '46,218,200709\n', '55,132,200630\n', '55,341,200612\n','54,404,200701\n', '23,114,200315\n', '55,223,200519\n', '34,218,200319\n', '33,132,200425\n','27,341,200422\n', '21,404,200501\n', '31,114,200503\n', '44,114,200513\n', '44,218,200519\n']
    print(media_02(lstResiduos))
    
main()