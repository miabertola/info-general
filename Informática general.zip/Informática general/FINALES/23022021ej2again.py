def ordenar(ls):
    for i in range(len(ls)-1):
        for j in range(1,len(ls)):
            if ls[i][1]>ls[j][1]:
                aux=ls[i]
                ls[i]=ls[j]
                ls[j]=aux

def energiaTotal(n,lstEnergia,lstParque):
    ls=[]
    for lineP in lstParque:
        lslineP=lineP[:-1].split(",")
        lslineP[0]=int(lslineP[0])
        lslineP[2]=int(lslineP[2])
        nom=lslineP[1]
        idp=lslineP[0]
        molinos=lslineP[2]
        cep=0
        for lineE in lstEnergia:
            lslineE=lineE[:-1].split(",")
            lslineE[1]=int(lslineE[1])
            lslineE[2]=float(lslineE[2])
            if idp==lslineE[1]:
                cep+=lslineE[2]
        cem=cep/molinos
        ls.append([nom,cep,cem])
    ordenar(ls)
    return ls[:n]
    
def main():
    print("Prueba para el EJ02")
    lstEnergia = ['101205,1,24.2\n', '110607,8,54.4\n', '120318,3,18.1\n','090501,9,88.4\n', '101209,1,26.8\n', '101217,3,22.4\n', '190101,8,44.0\n']
    lstParque = ['1,Rosario,8\n', '6,San Martin,4\n', '8,Lavalle,10\n','3,Esperanza,3\n', '7,General Pico,9\n', '9,P.Madryn,4\n']
    print(energiaTotal(3, lstEnergia, lstParque))
    
main()