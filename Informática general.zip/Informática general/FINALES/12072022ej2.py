def ordenar(lst):
    for i in range(1,len(lst)-1):
        for j in range(2,len(lst)):
            if lst[i][1]<lst[j][1]:
                aux=lst[i][1]
                lst[i][1]=lst[j][1]
                lst[j][1]=aux

def fun2t1(n):
    lsArch = ['club,jugador,partidos,minutos,goles,tiros,anio\n','(JUV),Cristiano Ronaldo,29,2634,25,162,2016\n','(PSG),Neymar,30,2694,13,105,2016\n', '(BAR),Lionel Messi,32,2910,37,179,2016\n', '(RMA),EdenHazard,36,3101,16,77,2016\n', '(TOT),Dele Alli,35,3182,18,95,2016\n', '(BAR),Lionel Messi,32,3123,33,197,2017\n','(JUV),Cristiano Ronaldo,27,2375,26,178,2017\n', '(BAR),Lionel Messi,29,2849,36,170,2018\n', '(JUV),CristianoRonaldo,30,2857,21,177,2018\n', '(PSG),Angel Di Maria,28,2418,12,97,2018\n', '(PSG),Neymar,16,1517,15,54,2018\n','(MNU),Edinson Cavani,20,1747,18,52,2018\n', '(RMA),Eden Hazard,32,3115,16,93,2018\n', '(BAR),LionelMessi,32,3067,25,159,2019\n', '(JUV),Cristiano Ronaldo,33,3127,31,208,2019\n', '(INT),LautaroMartinez,29,2581,14,125,2019\n', '(PSG),Neymar,15,1396,12,71,2019\n', '(PSG),Angel Di Maria,23,2106,8,74,2019\n','(BAR),Lionel Messi,8,824,4,39,2020\n', '(JUV),Cristiano Ronaldo,5,397,8,26,2020\n']
    ls=[]
    for lineJ in lsArch[1:]:
        lslineJ=lineJ[:-1].split(",")
        lslineJ[3]=int(lslineJ[3])
        jugador=lslineJ[1]
        if jugador not in ls:
            res=lslineJ[3]
        elif jugador in ls:
            res+=lslineJ[3]
        ls.append([jugador,res])
    ordenar(ls)
    return ls[:n]
    


def main():
#     print(fun2t1(0)) # []
    print(fun2t1(1)) # [['Lionel Messi', 12773]]
    print(fun2t1(2)) # [['Lionel Messi', 12773], ['Cristiano Ronaldo', 11390]]
    print(fun2t1(3)) # [['Lionel Messi', 12773], ['Cristiano Ronaldo', 11390], ['Eden Hazard', 6216]]
    print(fun2t1(4)) # [['Lionel Messi', 12773], ['Cristiano Ronaldo', 11390], ['Eden Hazard', 6216], ['Neymar', 5607]]
main()