import random
def cargarListaAleat(cant):
    ls=[]
    i=0
    while i<cant:
        i+=1
        ls.append(random.randint(0,2))
    return ls

def atributoTriple(ls):
    i=0
    triples=0
    while i<len(ls)-2:
        if ls[i]==ls[i+1] and ls[i]==ls[i+2]:
            if i==0 and (i+3<len(ls) and ls[i+3]!=ls[i] or i+3==len(ls)):
                triples +=1
                i+=3
            elif i>0 and i+3<len(ls) and ls[i+3]!=ls[i] and ls[i-1]!=ls[i]:
                triples+=1
                i+=3
            elif i>0 and i+3==len(ls) and ls[i-1]!=ls[i]:
                triples+=1
                i+=3
            else:
                i+=1
        else:
            i+=1
    if triples==0:
        msj="nada"
    elif triples==1:
        msj="1 Triple"
    elif triples==2:
        msj="2 Triples"
    else:
        msj="+ Triples"
    return msj

def main():
    lista=cargarListaAleat(15)
    print(lista)
    print(atributoTriple(lista))
    
main()