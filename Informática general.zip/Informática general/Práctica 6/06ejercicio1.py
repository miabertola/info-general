# def estaEnLista(num,lst):
#     if num in lst:
#         return True
#     else:
#         return False

# def estaEnLista2(num,lst):
#     for i in range(lst):
#         if num==i:
#             return True
#         else:
#             return False

def estaEnLista(num,lst):
    i=0
    while i<len(lst):
        i+=1
        if num==i:
        res=True
            return res
        else:
            res=False
            return res
    return res