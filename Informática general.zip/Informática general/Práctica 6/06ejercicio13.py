def agregarDicEle(di):
    print("Ingrese un numero entero y luego escríbalo. Finalice con 0: ")
    num=int(input())
    if num!=0:
        val=input()
    while num!=0:
        di[num]=val
        num=int(input())
        if num!=0:
            val=input()
            



def main():
    di={}
    agregarDicEle(di)
    print("Ingresar numero a traducir o cero para salir: ",end="")
    x=int(input())
    while x!=0 and x not in di:
        print("ERROR: Ingresar numero a traducir o cero para salir: ",end="")
        x=int(input())
    while x!=0:
        print("{}->{}".format(x,di[x]))
        x=int(input())
        while x!=0 and x not in di:
            print("ERROR: Ingresar numero a traducir o cero para salir: ",end="")
            x=int(input())
main()