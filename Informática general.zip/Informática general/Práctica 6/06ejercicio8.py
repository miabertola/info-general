def cargarLst():
    ls=[]
    x=int(input("Ingrese numero o cero (0) para terminar: "))
    while x!=0:
       if x!=0: 
        inserOrd(ls,x)
        x=int(input("Ingrese numero o cero (0) para terminar: "))
    return ls

def inserOrd(ls,num):
    i=0
    while i<len(ls) and num>ls[i]:
        i+=1
    ls.insert(i,num)
    
def main():
    print(cargarLst())
    
main()