import random
# (2,12,5,31,7) lista
# 6-9 intervalo
# nueva lista(7,9,6,8,7)
def cargarLista(lst):
    x=int(input("Ingresar numeros, o 0 (cero) para terminar: "))
    while x<0:
        x=int(input("ERROR. Numero NO positivo.\n"))
    while x!=0:
        lst.append(x)
        x=int(input())
        while x<0:
            x=int(input("ERROR. Numero NO positivo.\n"))
    
def cambiarLista(lst,a,b):
    for i in range(len(lst)):
        if lst[i]<a or lst[i]>b:
            lst[i]=random.randint(a,b)
            i+=1
        else:
            i+=1
    return(lst)
    
def main():
    lst=[]
    cargarLista(lst)
    print("Lista generada: ",lst)
    a=int(input("Ingrese limite a del rango: "))
    b=int(input("Ingrese limite b del rango: "))
    print("La lista modificada es: ")
    print((cambiarLista(lst,a,b)))
    
main()