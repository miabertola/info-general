def cargarLista():
    ls=[]
    x=int(input("Ingrese numero o cero (0) para terminar: "))
    while x!=0:
       if x!=0: 
        ls.append(x)
        x=int(input("Ingrese numero o cero (0) para terminar: "))
    return ls
    
def ordenar(ls):
    for i in range(0,len(ls)-1):
        for j in range(i+1,len(ls)):
            if ls[i]>ls[j]:
                aux = ls[i]
                ls[i] = ls[j]
                ls[j] = aux
    return ls

def main():
    print(ordenar(cargarLista()))
    
main()