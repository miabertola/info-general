def agregarDicEle(di):
    z=1
    while z:
        x=int(input("Ingresar numero entero, finalice con cero: "))
        if x!=0:
            numsp=input("En español: ")
            numen=input("En inglés: ")
            numde=input("En alemán: ")
            di[x]=(numsp,numen,numde)
        else:
            z=0

def main():
    di={}
    agregarDicEle(di)
    print()
    num=int(input("Ingrese numero a traducir o cero para salir: "))
    while num not in di and num!=0:
        num=int(input("No encontrado. Intente nuevamente: "))
    if num!=0:
        idi=input("Ingresar idioma en|sp|de: ")
        while id!="en" and idi!="sp" and idi!="de":
            idi=int(input("ERROR. Intente nuevamente"))
    while num:
        if idi=="sp":
            lang="español"
            pos=0
        elif idi=="en":
            lang="ingles"
            pos=1
        else:
            lang="aleman"
            pos=2
        print("{} en {}: {}".format(num,lang,di[num][pos]))
        print("Ingrese numero a traducir o cero para salir")
        num=int(input())
        while num not in di and num!=0:
            num=int(input("No encontrado. Intente nuevamente: "))
        if num!=0:
            idi=input("Ingresar idioma en|sp|de: ")
            while id!="en" and idi!="sp" and idi!="de":
                idi=int(input("ERROR. Intente nuevamente"))
        
main()