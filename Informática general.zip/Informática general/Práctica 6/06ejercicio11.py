import random
def porcentual(ls):
    #las claves van a ser los numeros y los valores las veces que aparecen
    di={}
    for x in ls:
        if x in di.keys():
            di[x]+=1
        else:
            di[x]=1
    for clave in di:
        print("El numero ",clave,"salió ",di[clave],"vez","(",di[clave]/len(ls)*100,"%)")

def ruleta(cant):
    ls=[]
    i=0
    while i<cant:
        i+=1
        ls.append(random.randint(0,36))
    return ls
        
def main():
    cant=int(input("Ingrese un numero entero: "))
    porcentual(ruleta(cant))
    
main()