def cargarLstAlu():
    lista=[]
    z=1
    while z:
        dni=int(input("Ingrese DNI: "))
        nombre=(input("Ingrese nombre: "))
        edad=int(input("Ingrese edad: "))
        lista.append([dni,nombre,edad])
        z=int(input("Desea continuar (0-1)?: "))
    return lista

def ordenarAluXDNI(ls):
    for i in range (len(ls)-1):
        for j in range (len(ls)-1):
            if ls[j][0]<ls[j+1][0]:
                aux=ls[j+1]
                ls[j+1]=ls[j]
                ls[j]=aux
    
def main():
    lista=cargarLstAlu()
    ordenarAluXDNI(lista)
    print(lista)
    
main()