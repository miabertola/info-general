def operaciones(a,b):
    ls=[]
    ls.append(a+b)
    ls.append(a-b)
    ls.append(a*b)
    if b!=0:
        ls.append(a/b)
    else:
        ls.append(None)
    return tuple(ls)

def main():
    print(operaciones(54,0))
    
main()