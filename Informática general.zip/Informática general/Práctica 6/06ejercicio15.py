def agregarDicEle():
    di={}
    z=1
    nota=1
    while z:
        dni=int(input("Ingrese DNI: "))
        nombre=input("Ingrese nombre: ")
        apellido=input("Ingrese apellido: ")
        di[dni]=[[nombre,apellido],[]]
        notas=int(input("Ingrese notas, finalice con 0: "))
        while notas!=0:
            di[dni][1].append(notas)
            notas=int(input())
        z=int(input("Desea continuar? (0,1)"))
    return di
            
def imprimirDic(di):
    print(di)
    
def imprimirDicOrd(di):
    ls=list(di.keys())
    for i in range(len(ls)-1):
        for j in range(len(ls)-1):
            if ls[j]>ls[j+1]:
                aux=ls[j]
                ls[j]=ls[j+1]
                ls[j+1]=aux
    for key in ls:
        print("{}--->{}".format(key,di[key]))
    
def main():
    di=agregarDicEle()
    imprimirDic(di)
    imprimirDicOrd(di)

main()