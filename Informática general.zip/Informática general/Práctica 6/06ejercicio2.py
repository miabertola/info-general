def enLista(x,ls):
    return x in ls

def cargarLista():
    ls=[]
    x=int(input("Ingresar numeros, o 0 (cero) para terminar: "))
    while x!=0:
        while x<0:
            x=int(input("ERROR numero negativo. Ingresar numeros, o 0 (cero) para terminar: "))
        if enLista(x,ls):
            x=int(input("ERROR numero en lista. Ingresar numeros, o 0 (cero) para terminar: "))
        else:
            if x!=0:
                ls.append(x)
                x=int(input("Ingresar numeros, o 0 (cero) para terminar: "))
    return ls

def main():
    ls=[]
    print(cargarLista())
    
main()