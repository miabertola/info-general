def esPrimo(num):
    primo=True
    for i in range(2,num):
        if num%i==0:
            primo=False
    return primo and num!=1

def ciclof2(i):
    for i in range (0,12):
        print(i,end=",")
    
    
def ciclof(msj):
    for x in msj:
        print(x,end=",")
        
def main():
    #ciclof("hola")#hay 4 elementos entonces va a dar 4 vueltas, cada vuelta toma un elemento
    #ciclof2("hola")
    #list(range(0,12))
    #print(esPrimo(13))
main()#el ciclo for en python lo dejo que termine solo, en while lo frenamos nosotros