#ciclos
# True -> si es primo
# False -> si no es primo
def esPrimoW(num):
    primo=True
    i=2
    while i<num and primo:
        if num%i==0:
            primo=False
        i=i+1
    return primo and num!=1

# def esPrimoF(num):
#     primo=True
#     i=2
#     for i in range (2,num):
#         if num%i==0:
#             primo=False
#     
#     return primo and num!=1

def main():
#     print(esPrimoF(1712))
#     print(esPrimoF(17))
    print(esPrimoW(4))
    
main()