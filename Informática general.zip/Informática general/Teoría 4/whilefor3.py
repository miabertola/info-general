def cicloW( ini, fin):
    i=ini # inicializa contador
    s=0 # inicializa sumador
    while (i<=fin): # while <condición>:
        if i%2==0:
            print(i,end=",")
            s =s+i # sumo los valores de i
            i+=1 # contador (inc) i=i+1
        i=i+1
    return s
def main():
    su=cicloW(0,5)
    print("La sumatoria de enteros entre 0 y 5 es:",su)
main()