def cicloW( inf, sup , num):
    res = None # inicializa variable respuesta
    esMulti=False # inicializa bandera
    i=inf # inicializa contador
    while (i<sup)and not esMulti: # while <condición>:
        if(i%num==0): # verificar si es múltiplo
            esMulti=True # cambia estado bandera
            res = i # i es el múltiplo encontrado
    i+=1 # contador, próximo numero
return res