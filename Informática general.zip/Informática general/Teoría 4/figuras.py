#el or suma y el and hace una intereseccion de figuras
#los corrimientos funcionan igual que en una funcion matematica
#entra un ejercicio en el teorico del final
def figuras(b):   
    for f in range(0,b):
        for c in range (0,b):
            if c==(2)*f:
                print(" *",end="")
            else:
                print(" ",end="")
        print()
        
def main():
    figuras(15)
    
main()