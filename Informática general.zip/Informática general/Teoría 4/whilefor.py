#con el while puedo hacer cualquier cosa, con for no, en python
def saludos(msj):
    i=0 #puede haber mas de una variable
    #variable de control, controla la ejecucion del ciclo
    while i<1000:#cantidad de vueltas que hace el while
        print(msj,end=",")
        
def main():
    saludos("hola")

main()