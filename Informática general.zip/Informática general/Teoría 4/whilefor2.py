# Programa_02
def cicloW(msj):
    i=0 # inicialización contador
    while (i < 5) : # while <condición>:
        print(msj) # instrucciones ...
        i = i+1 # contador (inc) i+=1
def main():
    cicloW("hola")
main()

#s=0 sumador
#s=x
#s=x+10