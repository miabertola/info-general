import random
def generarAle(inf,sup,cant):
    res=""
    for i in range (0,cant):
        al=random.randint(inf,sup)
        #print(al,end=",")
        res=res+str(al)+","
    return res
    
def main():
    print(generarAle(0,99,1000))
    
main()