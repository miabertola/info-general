#ciclo for
#cada vuelta qe pega se asigna un elemento de la secuencia, str o range
def cicloF(sec):
    for x in sec:
        print (x*10,end=",")
def cicloF2():
    for i in range(0,6):
        print(i,end="|")
        
        
def main():
    cicloF("hola")
    cicloF2()
main()