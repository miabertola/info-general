import random

def booleana():
    azar=random.randint(0,1)
    return azar

def main():
    ves1=input("Ingrese alternativa 1 para vestimenta: ")
    ves2=input("Ingrese alternativa 2 para vestimenta: ")
    pla1=input("Ingrese alternativa 1 para plato: ")
    pla2=input("Ingrese alternativa 2 para plato: ")
    beb1=input("Ingrese alternativa 1 para bebida: ")
    beb2=input("Ingrese alternativa 2 para bebida: ")
    azar=booleana()
    ves=azar*ves1+(1-azar)*ves2
    pla=azar*pla1+(1-azar)*pla2
    beb=azar*beb1+(1-azar)*beb2
    print("Cena al azar: {},{} y {}".format(ves,pla,beb))
    
main()