def crearFila(a):
    ancho="*"*a
    return ancho
    
def crearRectangulo(ancho,alto):
    rect=alto*(crearFila(ancho)+"\n")
    return rect

def main():
    ancho=int(input("Ingrese ancho: "))
    alto=int(input("Ingrese alto: "))
    print(crearRectangulo(ancho,alto))
    
main()