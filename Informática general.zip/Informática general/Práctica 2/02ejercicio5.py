import random

def generator(a,b):
    numero=random.randint(a,b)
    return numero

def main():
    num1=int(input("Ingrese el limite inferior (numero natural): "))
    num2=int(input("Ingrese el limite superior (numero natural): "))
    numero=random.randint(num1,num2)
    numero2=random.randint(numero,num2)
    numero3=random.randint(numero,numero2)
    print("1-Limite inferior {}, limite superior {}. Numero generado: {}\n2-Limite inferior {}, limite superior {}. Numero generado: {}\n3-Limite inferior {}, limite superior {}. Numero generado: {}".format(num1,num2,numero,numero,num2,numero2,numero,numero2,numero3))
    
main()