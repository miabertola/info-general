import math
def areaCirc(d):
    r=d/2
    area=math.pi*(r**2)
    return area

def areaCuad(l):
    area=l**2
    return area

def areaNegra(l):
    areaN=areaCuad(l)-areaCirc(l/3)*2-areaCirc(l*2/3)
    return areaN
    
def main():
    lado=int(input("Ingrese lado: "))
    porcentaje=areaNegra(lado)/areaCuad(lado)*100
    print("El area negra es {:.2f} y es un {:.2f} % del area total del cuadrado".format(areaNegra(lado),porcentaje))
    
main()