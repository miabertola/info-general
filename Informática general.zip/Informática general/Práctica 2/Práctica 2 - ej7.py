def justificado(fra,an):
    tamaño=("'{0:>{1}}'".format(fra,an-2))
    return tamaño

def main():
    frase=input("Ingrese la frase:")
    ancho=int(input("Ingrese el ancho total a ser usado:"))
    final=justificado(frase,ancho)
    print(final)

main()
    