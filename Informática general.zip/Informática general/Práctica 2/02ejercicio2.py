import math
def raiz(x,n):
    expo=1/n
    raiz=math.pow(x,expo)
    return raiz

def main():
    x=float(input("Ingrese el radicando (numero real): "))
    n=float(input("Ingrese el índice (numero natural): "))
    raizn=raiz(x,n)
    print("\nLa raiz {:.0f} de {:.0f} es = {:.6f}".format(n,x,raizn))

main()