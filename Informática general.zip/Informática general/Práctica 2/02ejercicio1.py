def areaTriangulo(a,b,c):
    p=(a+b+c)/2
    area=(p*(p-a)*(p-b)*(p-c))**0.5
    return area

def main():
    a=int(input("Ingrese lado 1: "))
    b=int(input("Ingrese lado 2: "))
    c=int(input("Ingrese lado 3: "))
    area=areaTriangulo(a,b,c)
    print("\nEl area del triángulo es = {:.2f}".format(area))
    
main()