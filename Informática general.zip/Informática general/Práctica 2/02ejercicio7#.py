def justificado(f,a):
    tamañototal=("'{0:>{1}}'".format(f,a-2)) #preguntar por el 1 y el 0 dentro del format
    return tamañototal
    
def main():
    frase=input("Ingrese la frase: ")
    ancho=int(input("Ingrese el ancho total a ser usado: "))
    final=justificado(frase,ancho)
    print(final)
    
main()