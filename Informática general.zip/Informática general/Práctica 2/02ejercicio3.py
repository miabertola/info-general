def paridad(nb):
    un=nb%10
    de=(nb//10)%10
    ce=(nb//100)%10
    um=(nb//1000)%10
    um2=(nb//10000)%10
    um3=(nb//100000)%10
    mi=(nb//1000000)%10
    mi2=(nb//10000000)%10
    paridad=(un+de+ce+um+um2+um3+mi+mi2)%2
    return paridad

def main():
    numbin=int(input("Ingrese un numero binario de hasta 8 bits: "))
    print("Bit de paridad generado: {}".format(paridad(numbin)))
    
main()