#formatos de salida
sal="{:6}+{:4}={}".format(12,20,32)
print(sal)

#padding