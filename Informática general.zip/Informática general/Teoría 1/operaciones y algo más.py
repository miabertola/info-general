entrada=input("Ingresar texto:")
print("------")
print(entrada)

#como saber que tipo de dato es
print(type(entrada),entrada)

# operaciones
num1=int(input("Ingresar Numero 1"))
num2=int(input("Ingresar Numero 2"))
suma=num1+num2
print("la suma es:",suma)
print(num1,"+",num2,"=",suma)			#+:sumar
print(num1,"-",num2,"=",num1-num2)		#-:restar
print(num1,"*",num2,"=",num1*num2)		#*:producto
print(num1,"/",num2,"=",num1/num2)		#/:division en reales
print(num1,"//",num2,"=",num1//num2)	#//:division entera
print(num1,"%",num2,"=",num1%num2)		#%:resto de la division entera
print(num1,"**",num2,"=",num1**num2)	#**:potencia