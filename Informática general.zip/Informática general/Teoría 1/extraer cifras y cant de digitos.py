#extraer cifras de un numero
num=1234
un=num%10
de=(num//10)%10
ce=(num//100)%10
um=(num//1000)%10
print(um,ce,de,un,sep="-")

#como extraer la cantidad de digitos
len("12345")