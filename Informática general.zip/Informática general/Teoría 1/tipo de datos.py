x=10
y=20
print(x)
print(y)
nombre="Juancito"
print(nombre)

#tipo de datos
entero=12		#int
real=3.1415		#float
texto="hola"	#str
textoN="12"		#str
esViernes=True	#bool
nada=None		#NoneType
print(entero)
print(textoN)