def main():
    aplazados=0
    aprobados=0
    promocionados=0
    notas=0
    suma=0
    nota=int(input("Ingrese nota (finalice con 0): "))
    while nota<1 or nota>10:
        nota=int(input("Ingrese nota (finalice con 0): "))
    
    while nota!=0:
        if nota<4 and nota>0:
            aplazados+=1
            notas+=1
            suma+=nota
        
        elif nota>=4 and nota<=7:
            aprobados+=1
            notas+=1
            suma+=nota
        
        elif nota>7 and nota<=10:
            promocionados+=1
            notas+=1
            suma+=nota

        nota=int(input("Ingrese nota (finalice con 0): "))

        
    print("\n")
    print("Cantidad de aplazos: {} ({:.2f}%)".format(aplazados,aplazados*100/notas))
    print("Cantidad de aprobados: {} ({:.2f}%)".format(aprobados,aprobados*100/notas))
    print("Cantidad de promocionados: {} ({:.2f}%)".format(promocionados,promocionados*100/notas))
    
    
main()