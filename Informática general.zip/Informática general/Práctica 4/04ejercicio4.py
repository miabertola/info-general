def perfecto(num):
    suma=0
    for i in range(1,num):
        if num%i==0:
            suma+=i
    if suma==num:
        return True
    else:
        return False

def main():
    cont=0
    i=1
    while cont<4:
        if (perfecto(i)):
            cont+=1
            print(i)
        i+=1
        
main()
        
            
            