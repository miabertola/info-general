def esPrimoW(num):
    primo=True
    i=2
    while i<num and primo:
        if num%i==0:
            primo=False
        i=i+1
    return primo and num!=1 and num!=0

def main():
    cant=int(input("Ingrese cantidad (numero natural): "))
#     for i in range(cant):
#         if esPrimoW(i):
#             print(i)
    i=0
    while i<cant:
        if esPrimoW(i):
            print(i)
        i=i+1
    
    i=0
    cont=0
    while cont<cant:
        if esPrimoW(i):
            print(i)
            cont+=1
        i=i+1
    
main()