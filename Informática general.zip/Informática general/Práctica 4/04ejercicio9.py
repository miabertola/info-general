def capi(num):
    numero=0
    for i in range(len(str(num))):
        dig=num//(10**i)%10
        numero=10*numero+dig
    if num==numero:
        return True
    else:
        return False
    
def main():
    num=123321
    print(capi(num))

main()