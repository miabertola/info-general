def fact(num):
    factorial=1
    if num==0:
        return 1
    else:
        for i in range(1,num+1):
            factorial*=i
        return factorial
        
def main():
    num=int(input("Ingrse un numero entero: "))
    if num>=0:
        print("El numero factorial de {} es: {}".format(num,fact(num)))
    
    else:
        print("No se puede calcular el factorial de un numero negativo")
        
main()