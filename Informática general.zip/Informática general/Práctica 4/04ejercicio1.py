def main():
    cont=0
    num=int(input("Ingrese numero entero: "))
    while cont<5:
        if (num%2)==0:
            cont+=1
            if num%4==0:
                print("Numero par. Tambien es múltiplo de 4. Total de numeros pares ingresados: {}".format(cont))
            else:
                print("Numero par. Total de numeros pares ingresados: {}".format(cont))
        if cont<5:
            num=int(input("Ingrese numero entero: "))
    print("\nFIN")
main()