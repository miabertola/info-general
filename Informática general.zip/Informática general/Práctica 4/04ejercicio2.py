def main():
    primero=0
    mayor=0
    menor=0
    num=int(input("Ingrese numeros enteros positivos (finalice con 0)"))
    while num<0:
        num=int(input("Ingrese numeros enteros positivos (finalice con 0)"))
    while num!=0:
        if primero==0:
            mayor=num
            menor=num
            primero+=1
        if num>mayor:
            mayor=num
        elif num<menor:
            menor=num
        num=int(input("Ingrese numeros enteros positivos (finalice con 0)"))
        while num<0:
            num=int(input("Ingrese numeros enteros positivos (finalice con 0)"))
    print("El mayor es {} y el menor es {}".format(mayor,menor))

main()