def tri(b):
    for y in range(1,b//2 + 2):
        for x in range(b):
            if x+y>=(b//2+2) and x-y<=(b//2):
                print("*",end="")
            else:
                print(" ",end="")
        print("")
        
    
def main():
    base=11
    if base>=3 and base%2!=0:
        return tri(base)
    else:
        return("numero no valido. ingrese base")
        
main()