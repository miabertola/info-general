def aBinario(x):
    num=0
    for i in range(10):
        binario=(x//(2**i)%2)*10**i
        num+=binario
    return num
  
def main():
    x=41
    print(aBinario(x))
main()