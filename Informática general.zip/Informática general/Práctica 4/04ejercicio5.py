def booleana(num):
    un=num%10
    de=(num//10)%10
    ce=(num//100)%10
    mi=(num//1000)%10
    if (un+ce)==(de+mi):
        return True
    else:
        return False
    
def main():
    num=0
    for i in range(1000,10000):
        if(booleana(i)):
            num+=1
            print(i)
            if num%10==0:
                print("\n")
    
main()