def tri(a):
    for y in range(1,a):
        for x in range(1,a):
            if y>=(x//2+1) and x>=y//2:
                print("*",end="")
            else:
                print(" ",end="")
        print("")
        
    
def main():
    a=7
    if a>=5 and a%2!=0:
        (tri(a))
    else:
        print ("numero no valido. ingrese base")
        
main()