def main():
    base=int(input("Ingrese base: ")) #7
    altura=int(input("Ingrese altura: ")) #4
    #while para validar
    for y in range(altura):#0-3
        for x in range(base): #0-6
            if x==0 or y==0 or y==altura-1 or x==base-1:
                print("*",end="")
            else:
                print(" ",end="")
        print("")
    
main()