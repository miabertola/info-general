def main():
    base=int(input("Ingrese base: ")) #7
    altura=int(input("Ingrese altura: ")) #3
    #while para validar
    for y in range(altura):
        for x in range(base): #0-6
            print("*",end="")
        print("")
    
main()