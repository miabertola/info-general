ls=[1,2,3]

lstA=[[10,"peras"],[7,"frutillas"],[2,"almendras"],[4,"limones"]]#[col0,col1]
#lstA[2][1][6]
#no puedo cambiar un caracter de string, tengo que cambiar todo el string
lstA.append([5,"kiwis"])
lstA.insert(0,[5,"kiwis"])
lstA.pop(0)
lstA[0].append("maduras")