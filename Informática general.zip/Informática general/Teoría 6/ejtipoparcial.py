"""
dado un texto, retornar una lista solo con las
palabras que tienen mayuscula
"""
#0123456789012345678901234567890123456 -> 37
#¡¿¡quE hacen, CON $esas$ )palabraS!!!
def esLetra(car):
    res = False
    acentos = car in "áéíóúüñÁÉÍÓÚÜÑ"
    if ((car>='a'and car<='z') or (car>='A' and car<='Z') or acentos  ):
        res = True
    return res

def esMay(letra):
    return letra>="A" and letra<="Z"

def contieneMay(p): #palabraS
    tieneM=False
    i=0
    while i<len(p) and tieneM==False:
        if esMay(p[i]):
            tieneM=True
        i+=1
    return tieneM

def listaDeMay(texto):
    i=0
    lst=[]
    while i<len(texto):
        while i<len(texto) and not esLetra(texto[i]):
            i+=1
        palabra=""
        while i<len(texto) and esLetra(texto[i]):
            palabra+=texto[i] #texto[i] es texto, i es un numero
            i+=1
        if contieneMay(palabra):
            lst.append(palabra)
    return lst