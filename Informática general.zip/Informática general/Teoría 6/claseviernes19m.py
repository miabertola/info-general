def intersección(la,lb):
    res=[]
    for a in la:
        if a in lb:
            res.append(a)
            
    return res
            
print(intersección([1,2,5,8],[2,99,77,8,-3]))
 
def union(la,lb):
    res=[]+la
    for b in lb:
        if b not in res:
            res.append(b)
            
    return res
print(union([1,2,5,8],[2,99,77,8,-3]))
#frase="&& 1000,999,   1 ab+c"
 
#["+",1000,999,1]
 
def operarLista(ls):
    res=0
    if ls!=[]:
        if ls[0]=="+":
            for i in range(1,len(ls)):
                res=res+ls[i]
        else:
            res=1
            for i in range(1,len(ls)):
                res=res*ls[i]
    return res
 
# def esLetra(c):
#     return (c>="a"and c<="z") or (c>="A"and c<="Z")
# def aLista(x): # lista con cantidad de leras de cada palabra
#     ls=[]
#     i=0
#     while i<len(x):
#         while i<len(x) and not esLetra(x[i]):
#             i+=1
#         pal=""
#         while i<len(x) and esLetra(x[i]):
#             pal=pal+x[i]
#             i+=1
#         #print(pal)
#         if pal!="":
#             ls.append(len(pal))
#     return ls
# def cargarTexto():
#     n=15
#     x=input("Ingrese frase de minimo {} caracteres o ENTER para salir:\n".format(n))
#     while len(x)<n and x!="" :
#         x=input("Reingrese frase de minimo {} caracteres o ENTER para salir:\n".format(n))
#     return x
# def main():
#     frase=cargarTexto()
#     #x="¡¡Asi      ramona     va, no Marisa!!"
#     if frase=="":
#         print("No se ingresó información")
#     else:
#         print(aLista(frase))
#       
# main()
 
 
 
 
# def esLetra(c):
#     return (c>="a"and c<="z") or (c>="A"and c<="Z")
# def aLista(x):
#     ls=[]
#     i=0
#     while i<len(x):
#         while i<len(x) and not esLetra(x[i]):
#             i+=1
#         pal=""
#         while i<len(x) and esLetra(x[i]):
#             pal=pal+x[i]
#             i+=1
#         #print(pal)
#         if pal!="":
#             ls.append(pal)
#     return ls
# def imprimirLista(ls):
#     cont=0
#     for x in ls:
#         print(x)
#         cont+=1
#     print("\nHay {} palabras".format(cont))    
# def main():
#     #x=input("Ingrese: ")
#     x="¡¡Asi      ramona     va, no Marisa!!"
#     ls=aLista(x)
#     imprimirLista(ls)    
# main()
 
 
# def esLetra(c):
#     return (c>="a"and c<="z") or (c>="A"and c<="Z")
# 
# def aPalabra(x):
#     res=""
#     i=0
#     while i<len(x):
#         while i<len(x) and not esLetra(x[i]):
#             i+=1
#         pal=""
#         while i<len(x) and esLetra(x[i]):
#             pal=pal+x[i]
#             i+=1
#         #print(pal)
#         if pal!="":
#             if res=="":
#                 res=pal
#             else:
#                 res=res+" "+pal
#     return res
# 
# def main():
#     #x=input("Ingrese: ")
#     x="¡¡Asi      ramona     va, no Marisa!!"
#     print(aPalabra(x))
# main()
 
# def aMin(c):
#     if c>="A"and c<="Z":
#         res=chr(ord(c)+32)
#     else:
#         res=c
#     return res
# 
# def esLetra(c):
#     return (c>="a"and c<="z") or (c>="A"and c<="Z")
# 
# def esPali(x):
#     xL="" #Es una frase con todos caracteres letra(Limpia)
#     i=0
#     while i<len(x):
#         while i<len(x) and not esLetra(x[i]):
#             i+=1    
#         while i<len(x) and esLetra(x[i]):
#             xL=xL+aMin(x[i])
#             i+=1
# 
#     return xL==xL[::-1]
# 
# def main():
#     #x=input("Ingrese: ")
#     x="¡¡Asi ramona va, no Marisa!!"
#     print(esPali(x))