def cambiarNum(n): #pasaje por valor
    n=n+1
    
def cambiarLista(lista): #pasaje por referencia
    lista.append(2)
    lista.insert(0,8)
    #lista = lst -> [8,2]

def main():
    numero=0
    lst=[]
    cambiarNum(numero)
    print(numero)
    cambiarLista(lst)
    print(lst)
    
main()