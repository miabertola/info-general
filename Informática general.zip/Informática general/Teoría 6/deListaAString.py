lista=["hola","soy","mia"]
texto=""
for x in lista:
    texto+=x+" "
print(texto)