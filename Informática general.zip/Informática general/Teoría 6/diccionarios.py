def main():
    #di={clave:valor}
    #di={} diccionario vacio
    #di={"Automovil":"Elemento creado...","Autor":"Persona que..."}
    di={10:"Claudia",20:"Lara",3:"Juan",69:"Agustina"}
    #la clave debe ser un inmutable
    di.get() #es lo mismo que el corchete, este método no rompe, si no está, devuelve None
    di.keys() #me devuelve todas las claves como si fuese una lista, es iterable
    list(di.keys())
    di.values() #me devuelve todos los valores del diccionario
    di.pop(por clave)
    di.pop(20)
    di[20]="Juancito"
    di[133]="Laura"
    #el diccionario no tiene orden, una cosa es imprimir un diccionario de forma ordenada
    di[10]="Pepe"
    #Perdi Claudia y no lo puedo volver a recuperar. si la clave ya existe se modifica el valor de la existencia de esa clave
    #pyhtontutor -> ver como funciona la memoria de python
    10 in di #para saber si una clave está en el diccionario
def mostrarDi(di):
    for k in di:#va asignando cada clave
        print(di[k])

def ordenarLista(ls):
    for i in range(0,len(ls)-1):
        for j in range(i+1,len(ls)):
            if ls[i]<ls[j]:
                aux=ls[i]
                ls[i]=ls[j]
                ls[j]=aux
            
def mostrarDi(di):#misma que arriba pero otra forma de hacerlo
    lsK=list(di.keys())#si yo quiero que este ordenado primero tengo que ordenar lsK
    prdenarLista(lsK)#el diccionario no se ordena, la lista si
    for k in lsK:#acá la recorre ordenada
        print(k,di[k])
    
def main():
    di={10:"Claudia",20:"Lara",3:"Juan",69:"Agustina"}
    
main()