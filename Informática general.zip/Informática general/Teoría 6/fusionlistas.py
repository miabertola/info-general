def fusion(l1,l2,res):
    for i in l1:
        if i not in l2 and i not in res:
            res.append(i)
    for i in l2:
        if i not in l1 and i not in res:
            res.append(i)
    return res

def main():
    l1=[15,2,6,2,6,4,10,9,5]
    l2=[7,3,4,8,3,12,5,20,3,4]
    res=[]
    fusion(l1,l2,res)
    print(res)

main()