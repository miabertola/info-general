def mostrar(ls):
    tit="{:<6}{:10}{:10}{:6}{:6}{:6}".format("DNI","NOMBRE","APELLIDO","P1","P2","P3")
    print(tit)
    for li in ls:
        salida="{:<6}{:10}{:10}{:6}{:6}{:6}".format(li[0],li[1],li[2],li[3][0],li[3][1],li[3][2])
        print(salida)
        
def agregarAlu(ls,dni,nom,ape):
    ls.append([dni,nom,ape,["-","-","-"]])

def main():
    lstAlu=[[11,"Thomas","Pool",["A","A","A"]],
            [222,"Juan","Lith",["A","A","D"]],
            [33,"Maria","Zul",["D","A","D"]],
            [44,"Juana","Charo",["D","D","D"]]
        ]
    agregarAlu(lstAlu,314,"Claudia","Olmos")
    agregarAlu(lstAlu,999,"Luis","Jara")
    mostrar(lstAlu)
    
main()