def cargarLista(lst): #las listas se pasan por referencia, no por valor.en vez de pasar el paquete de info a la funcion, le pasa la direc donde se pasa la lista
    lst.append("hola")
    lst.append("chau")
    lst.append(957)
def main():
    lst=[]
    cargarLista(lst)
    print(lst)
    
    
    
#     ls=[11,22,3,460,99,73] #podemos leer,escribir,achicar/borrar la lista, agregar o eliminar elementos,modificarlos
#     
#     
#     print("toda: ",type(ls),ls)
#     print(ls[2],",",ls[0])
#     print("último: ",ls[-1])
#     print("slice: ",ls[1:4])
#     print("------MODIFICAR------")
#     ls[2]="hola"
#     print(ls)
#     print("------AGREGAR------")
#     # al final
#     ls.append("oooohhh!!!!")
#     print(ls)
#     ls.append("oooohhh!!!!")
#     print(ls)
#     # en posicion
#     ls.insert(2,"chau")
#     print(ls)
#     #POR VALOR
#     ls.remove("oooohhh!!!!")
#     print(ls)
#     # por posicion
#     contBorr=ls.pop(4)
#     print("se borró: ",contBorr)
#     print(ls)
#     
main()