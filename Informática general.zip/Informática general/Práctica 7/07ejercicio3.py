def esLetra(car):
    res = False
    acentos = car in "áéíóúüñÁÉÍÓÚÜÑ"
    if ((car>='a'and car<='z') or (car>='A' and car<='Z') or acentos  ):
        res = True
    return res

def frecuenciaPalabra(nombre):
    file=open(nombre,"r")
    texto=""
    for linea in file:
        texto+=linea
    i=0
    di={}
    while i<len(texto):
        while i<len(texto) and not esLetra(texto[i]):
            i+=1
        pal=""
        while i<len(texto) and esLetra(texto[i]):
            pal+=texto[i]
            i+=1
        if pal and pal not in di.keys():
            di[pal]=1
        elif pal:
            di[pal]+=1
    string=""       
    for clave in di:
        string+="{}: {}\n".format(clave,di[clave])
    file.close()
    file=open("frecuencias.csv","w")
    file.write(string)
    file.close()
    
def main():
    frecuenciaPalabra("07ejercicio3.txt")
    file=open("frecuencias.csv","r")
    texto=""
    for linea in file:
        texto+=linea
    print(texto)
    file.close()
    
main()