def esLetra(car):
    res = False
    acentos = car in "áéíóúüñÁÉÍÓÚÜÑ"
    if ((car>='a'and car<='z') or (car>='A' and car<='Z') or acentos  ):
        res = True
    return res

def cabecera(arch,cant,pmin,pmax):
    file=open(arch,"r")
    texto=""
    for linea in file:
        texto+=linea
    file.close()
    total=0
    i=0
    lista=[]
    while i<len(texto):
        while i<len(texto) and not esLetra(texto[i]):
            i+=1
        pal=""
        while i<len(texto) and esLetra(texto[i]):
            pal+=texto[i]
            i+=1
        if pal and len(pal)>=pmin and len(pal)<=pmax and total<cant and pal not in lista:
            total+=1
            lista.append(pal)
    listado=""
    for pal in lista:
        listado+=pal+"\n"
        arch2=open("07ejercicio4resultado.csv","w")
        arch2.write(listado)
        arch2.close()
    
def main():
    cabecera("07ejercicio4.txt",100,6,9)

main()
