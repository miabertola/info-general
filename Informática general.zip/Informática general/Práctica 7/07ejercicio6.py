import random
def esLetra(car):
    res = False
    acentos = car in "áéíóúüñÁÉÍÓÚÜÑ"
    if ((car>='a'and car<='z') or (car>='A' and car<='Z') or acentos  ):
        res = True
    return res

def generadora(ori,dest,cant):
    file=open(ori,"r")
    texto=""
    for linea in file:
        texto+=linea
    file.close()
    i=0
    ls=[]
    while i<len(texto):
        while i<len(texto) and not esLetra(texto[i]):
            i+=1
        pal=""
        while i<len(texto) and esLetra(texto[i]):
            pal+=texto[i]
            i+=1
        if pal and pal not in ls:
            ls.append(pal)
    textofinal=""
    aux=[]
    total=0
    while total<cant:
        pos=random.randint(0,len(ls))
        if pos not in aux:
            textofinal+=ls[pos]+" "
            total+=1
            aux.append(pos)
    arch=open(dest,"w")
    arch.write(textofinal)
    file.close()          
    
def main():
    ori="7.6.fileorigen.txt"
    dest="7.6.filedestino.txt"
    cant=5
    generadora(ori,dest,cant)
    file=open(dest,"r")
    texto=""
    for line in file:
        texto+=line
    file.close()
    print(texto)


main()