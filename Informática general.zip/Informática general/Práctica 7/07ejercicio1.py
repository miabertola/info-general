def informe(nombre):
    arch=open(nombre,"r")
    z=1
    suma=0
    cont=0
    for num in arch:
        num=int(num)
        if z:
            minimo=num
            maximo=num
            suma+=num
            cont+=1
            z=0
        else:
            if num>maximo:
                maximo=num
            elif num<minimo:
                minimo=num
            suma+=num
            cont+=1
    lista=[maximo,minimo,suma/cont,cont]
    arch.close()
    return lista

def main():
    lista=informe("07ejercicio1.txt")
    print(lista)
    
main()