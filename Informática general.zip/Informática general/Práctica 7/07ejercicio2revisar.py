# [[87,56],[45,4,3],[12,3,5],[67,9,1,4]]
def agregarMedia(nombre):
    file=open(nombre,"r")
    str_med=""
    for line in file:
        str_med+=line
        lista=line.split(",")
        lista=lista[:-1]
        suma=0
        cont=0
        for num in lista:
            suma+=int(num)
            cont+=1
        str_med+="{:.2f}\n".format(suma/cont)
    file.close()
    file=open("07ejercicio2final.csv","w")
    file.write(str_med)
    file.close()
    return lista
    
def main():
    nombre="07ejercicio2.csv"
    agregarMedia(nombre)
    #la falla es que no se me separan bien las comas en el archivo
main()