def esLetra(car):
    res = False
    acentos = car in "áéíóúüñÁÉÍÓÚÜÑ"
    if ((car>='a'and car<='z') or (car>='A' and car<='Z') or acentos  ):
        res = True
    return res

def cabecera(arch,cant,pmin,pmax):
    file=open(arch,"r")
    texto=""
    for linea in file:
        texto+=linea
    file.close()
    total=0
    i=0
    while i<len(texto):
        while i<len(texto) and not esLetra(texto[i]):
            i+=1
        pal=""
        while i<len(texto) and esLetra(texto[i]):
            pal+=texto[i]
            i+=1
        if pal and len(pal)>=pmin and len(pal)<=pmax and total<cant:
            total+=1
            print(pal,end=",")    
    
def main():
    cabecera("07ejercicio4.txt",10,6,9)

main()