cad="aaa"
frase="hoy es (aaa) viernes (aaaaaa)y estoy feliz."
def contarCad2(cad,frase):##FALLA con cad=""
    cont=0 ##las apariciones de cad en frase
    i=0
    while i<len(frase):
        if frase[i:i+len(cad)]==cad:
            cont+=1
            i=i+len(cad)
        else:
            i+=1
    return cont
def main():
    print(contarCad2(cad,frase))
main()