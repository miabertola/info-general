# def aMayu(c):
#     if c>="a" and c<="z":
#         res=chr(ord(c)-32)
#         return res
#     else:
#         return c
    
def Amin(c):
    if c>="A" and c<="Z":
        res=chr(ord(c)+32)
        return res
    else:
        return c
    
def main():
    print(Amin("G"))
    
main()