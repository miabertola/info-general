def esLetra2(car):
    res = False
    acentos = car in "áéíóúüñÁÉÍÓÚÜÑ"
    if ((car>='a'and car<='z') or (car>='A' and car<='Z') or acentos  ):
        res = True
    return res

cad="aron"
frase="# $Baron!, urgente ya ha nacido! Es un varon$$$"

def verPal(frase):
    i=0
    pri=""
    ult=""
    largoFrase = len(frase)                       
    while i<largoFrase :
            while i<largoFrase and not esLetra2(frase[i]):
                i+=1
            pal=""
                
            while i<largoFrase and esLetra2(frase[i]):
                pal=pal+frase[i]
                i+=1
            if pal!="":
                print(pal,end=",")
                if pri=="":
                    pri=pal
                ult=pal
    print()
    print(pri,ult)