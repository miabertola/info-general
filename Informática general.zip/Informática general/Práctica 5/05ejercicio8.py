def esLetra2(car):
    res = False
    acentos = car in "áéíóúüñÁÉÍÓÚÜÑ"
    if ((car>='a'and car<='z') or (car>='A' and car<='Z') or acentos  ):
        res = True
    return res

def aMay(c):
    if c>="a" and c<="z":
        res=chr(ord(c)-32)
        return res
    else:
        return c

def frase(texto):
    i=0
    pal=""
    z=0
    while i<len(texto):
        while i<len(texto) and not esLetra2(texto[i]):
            pal+=texto[i]
            i+=1
        z=1
        while i<len(texto) and esLetra2(texto[i]):
            if z==1:
                pal+=aMay(texto[i])
                z=0
            else:
                pal+=texto[i]
            i+=1
    return pal

def main():
    texto="Soy el hombre mas sabio de la tierra"
    print(frase(texto))
    
main()