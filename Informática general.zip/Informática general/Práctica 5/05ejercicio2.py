def funcion(e,p):
    if (len(e))<2 or p==(""):
        return ""
    else:
        return (e[0]+p+e[1])

def main():
    extremo="{}"
    palabra="hola"
    print(funcion(extremo,palabra))

main()