def primeraMitad(pal):
    while len(pal)%2==0:
        l=len(pal)//2
        mitad=pal[:l]
        return mitad
        
def main():
    print(primeraMitad("mira"))
main()