def esLetra(car):
    res = False
    acentos = car in "áéíóúüñÁÉÍÓÚÜÑ"
    if ((car>='a'and car<='z') or (car>='A' and car<='Z') or acentos  ):
        res = True
    return res

def aMin(l):
    if l>="A" and l<="Z":
        l=chr(ord(l)+32)
    return l

def principioFin(frase):
    i=0
    pri=""
    ult=""
    largo=len(frase)
    while i<largo:
        while i<largo and not esLetra(frase[i]):
            i+=1
        pal=""
        while i<largo and esLetra(frase[i]):
            pal=pal+aMin(frase[i])
            i+=1
        if pal!="":
            if pri=="":
                pri=aMin(pal)
            ult=aMin(pal)
    if pri==ult:
        return ("El texto cumple la condicion")
    else:
        return ("El texto no cumple la condicion")

                
def main():
    print(principioFin("Hombre vamos hombre"))
main()