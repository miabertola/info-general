def word(word):
    if len(word)>=2:
        return (word[-2]+word[-1])*3
    else:
        return "palabra vacía"
def main():
    x="hola"
    print(word(x))
    
main()