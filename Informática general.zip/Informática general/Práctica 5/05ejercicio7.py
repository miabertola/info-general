cad="o sea"
frase="Bueno, yo o sea, este... o sea, o sea"
def contarCad2(cad,frase):##FALLA con cad=""
    cont=0 ##las apariciones de cad en frase
    i=0
    while i<len(frase):
        if frase[i:i+len(cad)]==cad:
            cont+=1
            i=i+len(cad)
        else:
            i+=1
    return cont
def main():
    print("El texto corto se encontró {} en el texto largo".format(contarCad2(cad,frase)))
main()