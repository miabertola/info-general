def rotacion(texto):
    m=len(texto)//2
    palabra=texto[m:]+texto[:m]
    return palabra

def main():
    texto=input("Ingrese un texto: ")
    while len(texto)%2!=0 or len(texto)<=2:
        texto=input("Errror. Ingrese un texto: ")
    print("La funcion ha retornado: ",rotacion(texto))
    
main()