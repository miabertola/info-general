def aMin(c):
    if c>="A" and c<="Z":
        res=chr(ord(c)+32)
    else:
        res=c
    return res

def esLetra(c):
    return (c>="a" and c<="z") or (c>="A" and c<="Z")

def esPali(x):
    xL="" #es una frase con todos los caracteres letra (limpia)
    i=0
    while i<len(x):
        while i<len(x) and not esLetra(x[i]):
            i+=1
        while i<len(x) and esLetra(x[i]):
            xL=xL+aMin(x[i])
            i+=1
    return xL==xL[::-1]

def main():
    #x=input("Ingrese: ")
    x="¡¡Así Ramona va, no Marisa!!"
    print(esPali(x))
    
main()