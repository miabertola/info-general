def aDec(num,base):
    if base>=2 and base<=9:
        n0=num%10
        n1=(num//10)%10
        n2=(num//100)%10
        n3=(num//1000)%10
        n4=(num//10000)%10
        decimal=n0*(base**0)+n1*(base**1)+n2*(base**2)+n3*(base**3)+n4*(base**4)
        return decimal

def main():
    base1=int(input("Ingrese la primera base: "))
    num1=int(input("\nIngrese numero en esa primera base: "))
    base2=int(input("\ningrese la primera base: "))
    num2=int(input("\nIngrese numero en esa segunda base: \n"))
    decimal1=(aDec(num1,base1))
    decimal2=(aDec(num2,base2))
    print(decimal1)
    print(decimal2)
    if decimal1>decimal2:
        print("{} es mayor que {}".format(decimal1,decimal2))
    elif decimal1==decimal2:
        print("{} y {} son iguales".format(decimal1,decimal2))
    else:
        print("{} es mayor que {}".format(decimal2,decimal1))
main()