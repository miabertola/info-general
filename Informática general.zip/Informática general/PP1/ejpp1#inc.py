# Se ingresa un numero de 6 cifras.
# verificar si la suma de los dos digitos de la derecha es
# igual a suma de los dos digitos de la izquierda.
# Verificar que el num tenga seis digitos para hacer el calculo
# La funcion  retorna el texto.
 
# 123456 -> 1+2 = 5+6 -> la suma no es igual.
# 231232 -> 2+3 = 3+2 -> la suma es igual y es 5.
# 9      ->           -> El numero no cumple la cantidad de cifras.
 
def obtenerDig(num,pos):
    res= (num//10**(pos))%10
    return res
def sumaDig(num,cant,op):
    #op -> 0 (son los cant dig de la derecha
    #op -> 1 (son los cant dig de la izq
    #cant -> 2 o cant -> 3
    u=obtenerDig(num,0)
    d=obtenerDig(num,1)
    c=obtenerDig(num,2)
    um=obtenerDig(num,3)
    dm=obtenerDig(num,4)
    cm=obtenerDig(num,5)
    if op==0:
        #derecha
        if cant==2:
            res=u+d
        elif cant==3:
            res=u+d+c
        else:
            res=-1
    else:
        #izquierda
        if cant==2:
            res=dm+cm
        elif cant==3:
            res=um+dm+cm
        else:
            res=-1
    return res
    
def sumaIguales(num):
    cd=len(str(num))
    res=""
    if cd==6:
        suma=sumaDig(num,2,0)
        if suma==sumaDig(num,2,1):
            res= "la suma es igual y es {}".format(suma)
        else:
            res= "la suma no es igual."
        
    else:
        res= "El numero no cumple la cantidad de cifras."
    return res
 
def main():
    num=int("231232") #input
    print(sumaIguales(num))   
    
main()