import math
def areaCirc(d):
    r=d/2
    area=math.pi*(r**2)
    return area
    
def areaTri(b,a):
    return b*a/2
    
def areaColor(d,letra):
    if letra=="n":
        negro=areaTri(d/3,d/3)*2+areaTri(d/3,d/6)
        return negro
    
    elif letra=="v":
        verde=areaCirc(d/3)+areaTri(d/3,d/6)
        return verde
    
    elif letra=="g":
        gris=areaCirc(d)-(areaTri(d/3,d/3)*2+areaTri(d/3,d/6))-areaCirc(d/3)+areaTri(d/3,d/6)
        return gris
        
    else:
        "ERROR"
def main():
    d=int(input("Ingrese diametro: \n"))
    letra=input("Ingrese inicial del color: \n")
    if letra=="n":
        print("El área negra es {:.2f}".format(areaColor(d,letra)))
    elif letra=="v":
        print("El area verde es {:.2f}".format(areaColor(d,letra)))
    elif letra=="g":
        print("El area gris es {:.2f}".format(areaColor(d,letra)))

main()