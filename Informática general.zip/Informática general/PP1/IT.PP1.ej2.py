import random
def elige(num):
    cifras=(len(str(num)))
    posicion=random.randint(0,cifras-1)
    cifra=num//(10**posicion)%10
    return cifra
    
def gen(num):
    un=elige(num)
    de=elige(num)
    ce=elige(num)
    return un+de*10+ce*100

def main():
    num=int(input("Ingrese un numero entero: "))
    num_gen=gen(num)
    print("\nUn llamado a Gen con parametro {} retorna {}. ".format(num,num_gen))
    if (num_gen%2)==0:
        print("{} es par.".format(num_gen))
    else:
        print("{} es impar.".format(num_gen))
        
main()