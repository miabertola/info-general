#2968395
num1=int(input("Ingrese un numero de cantidad impar de cifras (al menos 3 cifras): "))
numstr=str(num1)
cifras=len(numstr)
print("El numero ingresado tiene {} cifras.".format(cifras))
primera=num1//(10**(cifras-1))
ultima=num1%10
central=(num1//(10**(cifras/2)))%10
print("La primera cifra es {}, la ultima es {} y la central es {}.".format(primera,ultima,central))