num1=int(input("Ingrese el primer numero"))
num2=int(input("Ingrese el segundo numero"))
num3=int(input("Ingrese el tercer numero"))
suma=num1+num2+num3
print("\n{:=10}\n\n{:=10}\n\n{:=10}\n\n-------\n\n{:=10}".format(num1,num2,num3,suma))