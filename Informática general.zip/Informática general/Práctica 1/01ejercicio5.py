num1=int(input("Ingrese numero de cinco digitos: "))
un=num1%10
de=(num1//10)%10
ce=(num1//100)%10
um=(num1//1000)%10
um2=(num1//10000)%10
print(um2**2,um**2,ce**2,de**2,un**2,sep="-")