binario:int(input("Ingrese un numero binario: "))
num=(