num1=int(input("Ingrese el primer numero: "))
num2=int(input("Ingrese el segundo numero: "))
un1=num1%10
de2=(num2//10)%10
print("El numero resultante es: ",de2,un1,sep="")