multiplicando=int(input("Ingrese el multiplicando: "))
multiplicador=int(input("Ingrese el multiplicador: "))
unidad2=multiplicador%10
decena2=multiplicador//10%10
centena2=multiplicador//100
producto1=multiplicando*unidad2
producto2=multiplicando*decena2
producto3=multiplicando*centena2
resultado=multiplicando*multiplicador
print("{:10}\nx{:9}\n----------\n{:10}\n+{:8}-\n{:8}--\n----------\n{:10}".format(multiplicando,multiplicador,producto1,producto2,producto3,resultado))