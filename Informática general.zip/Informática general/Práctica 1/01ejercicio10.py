binario=int(input("Ingrese un numero binario: "))
un=binario%10
de=(binario//10)%10
ce=(binario//100)%10
um=(binario//1000)%10
um1=(binario//10000)%10
print("Numero en decimal: ",um1*(2**4)+um*(2**3)+ce*(2**2)+de*(2**1)+un*(2**0))