base=float(input("Ingrese base: "))
altura=float(input("Ingrese altura: "))
area=base*altura/2
perimetro=base+altura+(base**2+altura**2)**0.5
print("Calculos para un triangulo de base {:0.0f} y altura {:0.0f}:".format(base,altura))
print("<<<Area={:.2f}>>>\t<<<Perimetro={:.2f}>>>".format(area,perimetro))