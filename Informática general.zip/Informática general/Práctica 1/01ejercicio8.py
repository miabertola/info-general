#93714
tiempo=int(input("Ingrese tiempo en segundos: "))
dias=tiempo//86400
horas=(tiempo-dias*86400)//3600
minutos=(tiempo-dias*86400-horas*3600)//60
segundos=(tiempo-dias*86400-horas*3600-minutos*60)
print(dias,"dia(s)",horas,"hora(s)",minutos,"minuto(s)",segundos,"segundo(s)",sep=" ")