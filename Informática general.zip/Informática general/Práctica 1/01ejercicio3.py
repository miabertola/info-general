lado1=int(input("Ingrese lado 1: "))
lado2=int(input("Ingrese lado 2: "))
Perimetro=lado1*2+lado2*2
Area=lado1*lado2
print(Perimetro)
print(Area)
